import React from 'react'

const UserMessages = () => {
  return (<>
    <div className='courses-enrolled'>
    <h6>Messages</h6>
    </div>
    <div className='resume-div'></div>
    </>
  )
}

export default UserMessages