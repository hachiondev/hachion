import React from 'react'
import './Home.css';
import img1 from '../../Assets/image 11.png';
import img2 from '../../Assets/image 12.png'
import img3 from '../../Assets/image 13.png';
import img4 from '../../Assets/image 14.png'
import img5 from '../../Assets/image 15.png'
import img6 from '../../Assets/image 16.png'
import img7 from '../../Assets/image 17.png'
import img8 from '../../Assets/image 18.png'
import img9 from '../../Assets/image 19.png'
import img10 from '../../Assets/image 20.png'
import img11 from '../../Assets/image 21.png'
import img12 from '../../Assets/image 22.png'

const Association = () => {
  return (
    <>
<div className='association'>
    <h1 className='association-head'>Top IT firms collaborate with Hachion</h1>
    </div>
    <div className="logos">
	<div className="logos-slide">
	
			<img src={img1} height="50" width="auto" alt="image1" />
			<img src={img2} height="50" width="auto" alt="image2" />
			<img src={img3} height="50" width="auto" alt="image3" />
			<img src={img4} height="50" width="auto" alt="image4" />
			<img src={img5} height="50" width="auto" alt="image5" />
			<img src={img6} height="50" width="auto" alt="image6" />
			<img src={img7} height="50" width="auto" alt="image7" />
			<img src={img8} height="50" width="auto" alt="image8" />
			<img src={img9} height="50" width="auto" alt="image9" />
			<img src={img10} height="50" width="auto" alt="image10" />
			<img src={img11} height="50" width="auto" alt="image11" />
			<img src={img12} height="50" width="auto" alt="image12" />
	</div>
    <div className="logos-slide">
	
			<img src={img1} height="50" width="auto" alt="image1" />
			<img src={img2} height="50" width="auto" alt="image2" />
			<img src={img3} height="50" width="auto" alt="image3" />
			<img src={img4} height="50" width="auto" alt="image4" />
			<img src={img5} height="50" width="auto" alt="image5" />
			<img src={img6} height="50" width="auto" alt="image6" />
			<img src={img7} height="50" width="auto" alt="image7" />
			<img src={img8} height="50" width="auto" alt="image8" />
			<img src={img9} height="50" width="auto" alt="image9" />
			<img src={img10} height="50" width="auto" alt="image10" />
			<img src={img11} height="50" width="auto" alt="image11" />
			<img src={img12} height="50" width="auto" alt="image12" />
	</div>
    
</div>
    </>
  )
}

export default Association
