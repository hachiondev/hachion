import React from 'react'

const BatchType = () => {
  return (
   <>
   <div className='batch-type'>
 <p className='batch-type-content'>Live training</p>
  <p className='batch-type-content'>Crash Course</p>
 {/* <p className='batch-type-content'>Mentoring mode</p> */}
 <p className='batch-type-content'>Self-paced Learning</p>
 <p className='batch-type-content'>Corporate Training</p>
   </div>
   </>
  )
}

export default BatchType