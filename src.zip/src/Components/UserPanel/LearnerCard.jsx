import React, { useState } from 'react';
import './Corporate.css';
import { MdStar, MdStarHalf, MdStarOutline } from "react-icons/md";
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { FaUserAlt } from "react-icons/fa";

const renderStarRating = (rating) => {
  return [...Array(5)].map((_, i) => {
    const diff = rating - i;

    if (diff >= 1) {
      return <MdStar key={i} className="star-icon filled-star" />;
    } else if (diff >= 0.5) {
      return <MdStarHalf key={i} className="star-icon half-star" />;
    } else {
      return <MdStarOutline key={i} className="star-icon empty-star" />;
    }
  });
};
const LearnerCard = (props) => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <div className='learner-card'>
        <div className='learner-top'>
          <div className='learner-details'>
          <div className='learner-image'>
            {props.profileImage ? (
            <img
              alt={props.name}
              src={props.profileImage}
              variant="square"
              className="profile-image"
            />
          ) : (
            <div variant="square" className="profile-image">
              <FaUserAlt size={28} color='#b3b3b3'/>
            </div>
          )}
          </div>
          <div className='learner-info'>
            <div className='learner-name'>
              <p className='name'>{props.name}</p>
            </div>
            <p className='job-location'>
              {props.location || ""}</p>
            <p className='company-name'>
              {props.company || ""}</p>
          </div>
          </div>
          <div className='rating'>{renderStarRating(props.rating)}</div>
          </div>
        <p className='name'>{props.role}</p>
        <div className="learner-description-bottom">
        <p className="learner-description">
          {props.content && props.content.length > 150
            ? (
              <>
                {props.content.substring(0, 150)}...
                <span className="read-more" onClick={() => setOpen(true)}>
                  {" "}Read More
                </span>
              </>
            )
            : props.content}
        </p>
      </div>
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle className='top'>
          {props.name}'s Review
          <IconButton aria-label="close" onClick={() => setOpen(false)} className='close-button'>
            <CloseIcon style={{color: '#3D3D3D', background: 'none', borderRadius: '50%'}}/>
          </IconButton>
        </DialogTitle>
        <DialogContent>
          <div className='popup-content'>
            <div className='learner-top'>
             <div className='learner-details'>
          <div className='learner-image'>
            {props.profileImage ? (
            <img
              alt={props.name}
              src={props.profileImage}
              variant="square"
              className="profile-image"
            />
          ) : (
            <div variant="square" className="profile-image">
              <FaUserAlt size={28} color='#b3b3b3'/>
            </div>
          )}
            </div>
            <div className='learner-info'>
            <div className='learner-name'>
            <p className='name'>{props.name}</p>
            </div>
            <p className='job-location'>{props.location}</p>
            <p className='company-name'>
              {props.company || ""}</p>
            </div>
            </div>
            <div className='rating'>{renderStarRating(props.rating)}</div>
            </div>
            <p className='name'>{props.role || ""}</p>
            <p className='learner-description'>{props.content}</p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default LearnerCard;