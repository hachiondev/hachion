import React from 'react'
import Curriculum from './Curriculum';




const CurriculumMain = () => {
  return (
    <>
    <div>
      <Curriculum 
        heading="Curriculum"
      
        buttonText="Download Curriculum"
     
      />
   
    </div>
    
    </>
  )
}

export default CurriculumMain
