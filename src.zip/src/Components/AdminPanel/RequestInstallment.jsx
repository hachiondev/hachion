import * as React from 'react';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Checkbox,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { tableCellClasses } from '@mui/material/TableCell';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { IoSearch } from "react-icons/io5";
import { useState, useEffect } from 'react';
import AdminPagination from './AdminPagination';
import { FaCheckCircle } from 'react-icons/fa';
import { RiCloseCircleLine } from 'react-icons/ri';
import NoData from '../../Assets/nodata.webp'
import './Admin.css';
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
import axios from 'axios';


dayjs.extend(customParseFormat);
const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: '#00AEEF',
        color: theme.palette.common.white,
        borderRight: '1px solid white', 
        padding: '3px 5px',
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
        padding: '3px 4px',
        borderRight: '1px solid #e0e0e0', 
    },
}));
const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));
export default function RequestInstallment() {
    const [requestInstallment, setRequestInstallment] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [filteredRows, setFilteredRows] = useState([]);
    const filteredData = requestInstallment.filter((item) => {
        const date = new Date(item.date || item.payment_date);
        const matchesSearch =
          searchTerm === '' ||
          [item.student_ID, item.userName, item.email, item.mobile, item.course_name, item.requestInstallments, item.requestStatus, item.date ? dayjs(item.date).format('MMM-DD-YYYY') : '']
            .map(field => (field || '').toLowerCase())
            .some(field => field.includes(searchTerm.toLowerCase()));
        const inDateRange =
          (!startDate || date >= new Date(startDate)) &&
          (!endDate || date <= new Date(endDate));
        return matchesSearch && inDateRange;
      });
    
      const displayedData = filteredData.slice(
        (currentPage - 1) * rowsPerPage,
        currentPage * rowsPerPage
      );
       const handleDateFilter = () => {
          const filtered = requestInstallment.filter((item) => {
            const itemDate = dayjs(item.date);
            return (
              (!startDate || itemDate.isAfter(dayjs(startDate).subtract(1, 'day'))) &&
              (!endDate || itemDate.isBefore(dayjs(endDate).add(1, 'day')))
            );
          });
          setFilteredRows(filtered);
        };
      
        const handleDateReset = () => {
          setStartDate(null);
          setEndDate(null);
          setFilteredRows(requestInstallment);
        };
        useEffect(() => {
        setFilteredRows(requestInstallment);
      }, [requestInstallment]);


useEffect(() => {
  const fetchRequestInstallments = async () => {
    try {
      const response = await axios.get('https://api.test.hachion.co/razorpay/request-installments');
      
      const mappedData = response.data.map((item) => ({
        id: item.id,
        student_ID: item.studentId,
        userName: item.studentName,
        email: item.payerEmail,
        mobile: item.mobile,
        course_name: item.courseName,
        batch_id: item.batchId,
        fee: item.courseFee,
        requestInstallments: item.numSelectedInstallments,
        date: item.requestDate,
         
        coupon: ''   ,
        requestStatus: item.requestStatus     
      }));

      setRequestInstallment(mappedData);
      setFilteredRows(mappedData);
    } catch (error) {
      console.error('Error fetching installment requests:', error);
    }
  };

  fetchRequestInstallments();
}, []);

    return (
        <>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <div className='course-category'>
                      <div className='category-header'><p style={{ marginBottom: 0 }}>View Installment requests</p></div>
                      <div className='date-schedule'>
                                  Start Date
                                  <DatePicker 
                          selected={startDate} 
                          onChange={(date) => setStartDate(date)} 
                          isClearable 
                          sx={{
                            '& .MuiIconButton-root':{color: '#00aeef'}
                        }}/>
                                  End Date
                                  <DatePicker 
                          selected={endDate} 
                          onChange={(date) => setEndDate(date)} 
                          isClearable 
                          sx={{
                            '& .MuiIconButton-root':{color: '#00aeef'}
                        }}
                        />
                      <button className='filter' onClick={handleDateFilter}>Filter</button>
                      <button className="filter" onClick={handleDateReset}>Reset</button>
                                </div>
                      <div className='entries'>
                        <div className='entries-left'>
                          <p style={{ marginBottom: '0' }}>Show</p>
                          <div className="btn-group">
                            <button type="button" className="btn-number dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                              {rowsPerPage}
                            </button>
                            <ul className="dropdown-menu">
                              <li><a className="dropdown-item" href="#!" onClick={() => setRowsPerPage(10)}>10</a></li>
                              <li><a className="dropdown-item" href="#!" onClick={() => setRowsPerPage(25)}>25</a></li>
                              <li><a className="dropdown-item" href="#!" onClick={() => setRowsPerPage(50)}>50</a></li>
                            </ul>
                          </div>
                          <p style={{ marginBottom: '0' }}>entries</p>
                        </div>
                        <div className='entries-right'>
                          <div className="search-div" role="search" style={{ border: '1px solid #d3d3d3' }}>
                            <input
                              className="search-input"
                              type="search"
                              placeholder="Enter Name, Course Name, Imstallments or Keywords"
                              aria-label="Search"
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                            />
                            <button className="btn-search" type="submit">
                              <IoSearch style={{ fontSize: '2rem' }} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </LocalizationProvider>
            
                  <TableContainer component={Paper}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell align='center'><Checkbox /></StyledTableCell>
                            <StyledTableCell align='center'>S.No.</StyledTableCell>
                            <StyledTableCell align='center'>Student ID</StyledTableCell>
                            <StyledTableCell align='center'>Student Name</StyledTableCell>
                            <StyledTableCell align='center'>Email</StyledTableCell>
                            <StyledTableCell align="center">Mobile</StyledTableCell>
                            <StyledTableCell align="center">Course Name</StyledTableCell>
                            <StyledTableCell align="center">Course Fee</StyledTableCell>
                            <StyledTableCell align="center">Requested Installments</StyledTableCell>
                            <StyledTableCell align="center">Created Date </StyledTableCell>
                            <StyledTableCell align="center">Status</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                    {displayedData.length > 0 ? (
              displayedData.map((row, index) => (
                <StyledTableRow key={row.id || index}>
                            <StyledTableCell><Checkbox /></StyledTableCell>
                            {/* <StyledTableCell>{index + 1}</StyledTableCell> */}
                             <StyledTableCell>
      {(currentPage - 1) * rowsPerPage + index + 1}
    </StyledTableCell>
                            <StyledTableCell align="left">{row.student_ID}</StyledTableCell>
                            <StyledTableCell align="left">{row.userName}</StyledTableCell>
                            <StyledTableCell align="left">{row.email}</StyledTableCell>
                            <StyledTableCell align="center">{row.mobile}</StyledTableCell>
                            <StyledTableCell align="left">{row.course_name}</StyledTableCell>
                            <StyledTableCell align="left">{row.fee}</StyledTableCell>
                            <StyledTableCell align="center">{row.requestInstallments}</StyledTableCell>
                            <StyledTableCell align="center">{dayjs(row.date).format('MMM-DD-YYYY')}</StyledTableCell>
                            
                            <StyledTableCell align="center">
  <div style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'center' }}>
    {row.requestStatus === 'approved' ? (
      <span className="approved">Approved</span>
    ) : row.requestStatus === 'rejected' ? (
      <span className="rejected">Rejected</span>
    ) : (
      <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
        <FaCheckCircle
          className="approve"
          style={{ cursor: 'pointer', color: 'green' }}
          onClick={async () => {
            try {
              await axios.put(`https://api.test.hachion.co/razorpay/update-status/${row.id}`, null, {
                params: { requestStatus: "approved" },
              });
              
              const updatedData = requestInstallment.map((item) =>
                item.id === row.id ? { ...item, requestStatus: "approved" } : item
              );
              setRequestInstallment(updatedData);
              setFilteredRows(updatedData);
            } catch (error) {
              console.error("Error updating requestStatus:", error);
            }
          }}
        />
        <RiCloseCircleLine
          className="reject"
          style={{ cursor: 'pointer', color: 'red' }}
          onClick={async () => {
            try {
              await axios.put(`https://api.test.hachion.co/razorpay/update-status/${row.id}`, null, {
                params: { requestStatus: "rejected" },
              });
              
              const updatedData = requestInstallment.map((item) =>
                item.id === row.id ? { ...item, requestStatus: "rejected" } : item
              );
              setRequestInstallment(updatedData);
              setFilteredRows(updatedData);
            } catch (error) {
              console.error("Error updating requestStatus:", error);
            }
          }}
        />
      </div>
    )}
  </div>
</StyledTableCell>

                            </StyledTableRow>
                             ))
                            ) : (
                            <StyledTableRow>
                            <StyledTableCell colSpan={11} align="center" className="program-schedule"><img src={NoData} alt="No Data" />
                            <p>No data available</p>
                            </StyledTableCell>
                            </StyledTableRow>
                            )}
                        </TableBody>
                       </Table>
                       </TableContainer>
                            
                        <div className='pagination-container'>
                         <AdminPagination
                          currentPage={currentPage}
                          rowsPerPage={rowsPerPage}
                          totalRows={filteredData.length}
                          onPageChange={setCurrentPage}
                        />
                        </div>
         </>
       );
     }
                            