import React from 'react'

const CandidateCertificate = () => {
  return (
    <div>CandidateCertificate</div>
  )
}

export default CandidateCertificate