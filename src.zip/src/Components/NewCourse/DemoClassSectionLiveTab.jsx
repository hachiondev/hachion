
import React, { useEffect, useState } from "react";
import styles from "./DemoClassSection.module.css";
import { cn } from "../../utils";
import { useCheckEnrollmentForSessions } from "../../Api/hooks/CourseApi/useCheckEnrollmentForSessions";
import { useNavigate } from "react-router-dom";
import { useResendEnrollEmail } from "../../Api/hooks/CourseApi/useResendEnrollEmail";


function DemoClassSectionLiveTab({
  scheduleLoading,
  scheduleError,
  liveGroups,
  selectedGroupKey,
  setSelectedGroupKey,
  selectedGroup,
  isRequestBatchLoading,
  isProfileLoading,
  showMessage,
  isRequestBatchSuccess,
  requestBatchError,
  onRequestClick,
  liveTraining,
  isCourseLoading,
  courseError,
  userProfile,
  courseName,
  onEnrollClick,
  enrollSuccessMessage,
  enrollErrorMessage,
  showRegisterPrompt,
  onCloseRegisterPrompt,
  enrollingSessionId,
  onResendClick,
  resetLiveSubmitting
}) {

  const liveContent =
    liveTraining && liveTraining.trim().length > 0
      ? liveTraining
      : `Join real-time instructor-led sessions from anywhere. This mode includes interactive classes, hands-on exercises, and live Q&A to ensure in-depth learning.

What's Included:
• 80+ hours of video content
• 15 modules with over 150 lessons
• 5 real-world projects
• Professional Certificate upon completion
• English
• Lifetime access with free updates
• No prior programming experience required`;
  const { data: checkedSessions = [] } = useCheckEnrollmentForSessions(
    selectedGroup?.sessions || [],
    userProfile?.studentId || "",
    courseName || ""
  );
  const navigate = useNavigate();


  const { mutate: resendEmail } = useResendEnrollEmail();

  const [sendingBatchId, setSendingBatchId] = React.useState(null);
  const [resendMessage, setResendMessage] = React.useState("");
  const [resendError, setResendError] = React.useState("");
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [notifyVia, setNotifyVia] = useState({
  email: true,
  whatsapp: false,
});


  useEffect(() => {
    if (!resendMessage && !resendError) return;

    const t = setTimeout(() => {
      setResendMessage("");
      setResendError("");
    }, 10000);

    return () => clearTimeout(t);
  }, [resendMessage, resendError]);
  useEffect(() => {
    if (isRequestBatchSuccess || requestBatchError) {
      setIsSubmitting(false);
    }
  }, [isRequestBatchSuccess, requestBatchError]);

  useEffect(() => {
    setIsSubmitting(false); // ✅ reset when modal closes
  }, [resetLiveSubmitting]);

const handleNotifyChange = (e) => {
  const { name, checked } = e.target;

  setNotifyVia((prev) => ({
    ...prev,
    [name]: checked,
  }));
};


  return (
    <div className={styles.dcgrid}>
      <div>
        <div className={styles.dcslots}>
          {scheduleLoading && (
            <div className={styles.dcslot}>
              <div className={styles.dcslotdate}>Loading slots...</div>
            </div>
          )}

          {!scheduleLoading && scheduleError && (
            <div className={styles.dcslot}>
              <div className={styles.dcslotdate}>
                Failed to load schedule. Please try again.
              </div>
            </div>
          )}

          {!scheduleLoading &&
            !scheduleError &&
            liveGroups &&
            liveGroups.length > 0 &&
            liveGroups.map((g) => (
              <div
                key={g.key}
                className={cn(
                  styles.dcslot,
                  selectedGroupKey === g.key && styles.dcslotActive
                )}
                onClick={() => setSelectedGroupKey(g.key)}
              >
                <div className={styles.dcslotdate}>{g.day}</div>

                <div className={styles.dcslotcount}>
                  <strong>
                    {g.totalSlots} {g.totalSlots === 1 ? "Slot" : "Slots"}
                  </strong>
                </div>

                <div
                  className={cn(
                    styles.dcslotbadge,
                    g.type === "live"
                      ? styles.dcslotbadgeislive
                      : styles.dcslotbadgeisdemo
                  )}
                >
                  {g.totalSlots}{" "}
                  {g.type === "live"
                    ? "Live"
                    : g.totalSlots === 1
                      ? "demo"
                      : "demos"}
                </div>
              </div>
            ))}

          {!scheduleLoading &&
            !scheduleError &&
            (!liveGroups || liveGroups.length === 0) && (
              <div className={styles.dcslot}>
                <div className={styles.dcslotdate}>
                  No live batches scheduled
                </div>
              </div>
            )}
        </div>

        {selectedGroup && (
          <div className={styles.dcdetails}>
            <div className={styles.dcdetailscol}>
              <h4>Class Details</h4>

              <div
                style={{
                  maxHeight: "240px",
                  overflowY:
                    selectedGroup.sessions.length > 2 ? "auto" : "hidden",
                  paddingRight:
                    selectedGroup.sessions.length > 2 ? "8px" : "0",
                  boxSizing: "border-box",
                }}
              >
                {checkedSessions.map((sess) => (
                  <div key={sess.id} className={styles.dcdetailrow}>
                    <div>
                      <div className={styles.dcmuted}>
                        {sess.mode === "Live Demo" ? "Demo Session" : "Live Class"}
                      </div>

                      <div className={styles.dcdetailtime}>{sess.time}</div>

                      <div className={styles.dcdetailmeta}>
                        {sess.duration || "60 min"}
                      </div>
                    </div>
{sess._isEnrolled ? (
  <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>

    {/* Enrolled Button */}
    <button
      className={styles.dcbtn}
      disabled
      style={{ background: "#ccc", color: "#555" }}
    >
      Enrolled
    </button>



    {/* Resend Button */}
    <button
      className={styles.dclink}
      disabled={sess.resendCount >= 3 || sendingBatchId === sess.batchId}
      onClick={() => {
        setSendingBatchId(sess.batchId);

        resendEmail(
          {
            email: userProfile.email,
            batchId: sess.batchId,
            notifyVia, // 👈 send selected options
          },
          {
            onSuccess: (msg) => {
              setSendingBatchId(null);
              setResendError("");
              setResendMessage(typeof msg === "string" ? msg : msg?.message);
            },
            onError: (err) => {
              setSendingBatchId(null);
              const backendMsg =
                typeof err?.response?.data === "string"
                  ? err.response.data
                  : err?.response?.data?.message;

              setResendMessage("");
              setResendError(backendMsg || "Failed to resend email");
            },
          }
        );
      }}
    >
      {sess.resendCount >= 3
        ? "Limit Reached"
        : sendingBatchId === sess.batchId
        ? "Sending..."
        : "Resend"}
    </button>
  </div>
) : (
<>
  <div className={styles.enrollActions}>
    <button
      className={styles.dcbtn}
      disabled={enrollingSessionId === sess.id}
      onClick={() => onEnrollClick(sess)}
    >
      {enrollingSessionId === sess.id ? "Enrolling..." : "Enroll"}
    </button>

    {/* Notification Options */}
    <div className={styles.notifyOptions}>
      <label className={styles.notifyLabel}>
        <input
          type="checkbox"
          name="email"
          checked={notifyVia.email}
          onChange={handleNotifyChange}
        />
        <span>Email</span>
      </label>

      <label className={styles.notifyLabel}>
        <input
          type="checkbox"
          name="whatsapp"
          checked={notifyVia.whatsapp}
          onChange={handleNotifyChange}
        />
        <span>WhatsApp</span>
      </label>
    </div>
  </div>
</>

)}

                  </div>
                ))}



              </div>
            </div>

            <div className={cn(styles.dcdetailscol, styles.dcempty)}>
              <div className={styles.dcemptyicon}>
                <img src="/calendar.png" alt="calendar" />
              </div>

              <p className={styles.dcemptytext}>
                Be the first to request a custom demo session at your preferred
                time
              </p>

              <button
                className={styles.dclink}
                disabled={isSubmitting || isRequestBatchLoading || isProfileLoading}
                onClick={() => {
                  if (isSubmitting || isRequestBatchLoading) return;

                  setIsSubmitting(true);
                  onRequestClick();
                }}
              >
                {isSubmitting || isRequestBatchLoading ? "Submitting..." : "Request Batch"}
              </button>


              {enrollSuccessMessage && (
                <p style={{ color: "green", fontSize: "14px", marginTop: "6px" }}>
                  {enrollSuccessMessage}
                </p>
              )}

              {enrollErrorMessage && (
                <p style={{ color: "red", fontSize: "14px", marginTop: "6px" }}>
                  {enrollErrorMessage}
                </p>
              )}

              {showMessage && isRequestBatchSuccess && (
                <p
                  style={{
                    color: "#0A8754",
                    fontSize: "14px",
                    marginTop: "6px",
                    lineHeight: "1.4",
                  }}
                >
                  Your request has been submitted successfully.
                  <br />
                  Our team will contact you shortly with batch details.
                </p>
              )}

              {showMessage && requestBatchError && (
                <p
                  style={{
                    color: "#D93025",
                    fontSize: "14px",
                    marginTop: "6px",
                    lineHeight: "1.4",
                  }}
                >
                  Unable to submit your request right now.
                  <br />
                  Please try again in a few minutes.
                </p>
              )}

              {resendMessage && (
                <p style={{ color: "green", fontSize: "13px" }}>
                  {resendMessage}
                </p>
              )}

              {resendError && (
                <p style={{ color: "red", fontSize: "13px" }}>
                  {resendError}
                </p>
              )}
            </div>
          </div>
        )}
      </div>
      {showRegisterPrompt && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background: "rgba(0,0,0,0.55)",
            zIndex: 9999,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div
            style={{
              width: "520px",
              background: "#fff",
              borderRadius: "12px",
              display: "flex",
              padding: "20px",
              boxShadow: "0 10px 35px rgba(0,0,0,0.28)",
            }}
          >
            {/* LEFT SIDE — GIRL IMAGE */}
            <div
              style={{
                width: "42%",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <img
                src={require("../../Assets/loginpopup.webp")}
                alt="login popup"
                style={{
                  width: "100%",
                  borderRadius: "8px",
                  objectFit: "cover",
                  transform: "scaleX(-1)"
                }}
              />

            </div>

            {/* RIGHT SIDE — TEXT + BUTTONS */}
            <div
              style={{
                width: "58%",
                paddingLeft: "14px",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
              }}
            >
              <h3
                style={{
                  margin: 0,
                  fontSize: "20px",
                  color: "#222",
                  marginBottom: "6px",
                }}
              >
                Please Login
              </h3>

              <p
                style={{
                  fontSize: "14px",
                  marginBottom: "20px",
                  color: "#555",
                  lineHeight: "1.4",
                }}
              >
                Before proceeding, please login into our Hachion.
              </p>

              <div style={{ display: "flex", gap: "10px" }}>
                <button
                  style={{
                    padding: "8px 14px",
                    borderRadius: "6px",
                    border: "none",
                    background: "#2563eb",
                    color: "#fff",
                    fontSize: "14px",
                    cursor: "pointer",
                  }}
                  onClick={() => {
                    navigate("/login");
                    onCloseRegisterPrompt && onCloseRegisterPrompt();
                  }}
                >
                  Login
                </button>

                <button
                  style={{
                    padding: "8px 14px",
                    background: "#f1f5f9",
                    color: "#333",
                    borderRadius: "6px",
                    border: "1px solid #ccc",
                    fontSize: "14px",
                    cursor: "pointer",
                  }}
                  onClick={() => onCloseRegisterPrompt && onCloseRegisterPrompt()}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* RIGHT: Dynamic Info Card */}
      <aside className={styles.dcinfo}>
        <div className={styles.dcinfohead}>
          <div className={styles.dcinfoicon} aria-hidden="true">
            <img src="/share.png" alt="share" />
          </div>
          <div>
            <div className={styles.dcinfotitle}>Live Training</div>
            <div className={styles.dcinfosubdescription}>Learning Mode</div>
          </div>
        </div>

        {isCourseLoading ? (
          <div className={styles.dcinfotext}>Loading live training details...</div>
        ) : (
          <div
            className={styles.dcinfotext}
            style={{ whiteSpace: "pre-line" }}
          >
            {liveContent}
          </div>
        )}
      </aside>
    </div>
  );
}

export default DemoClassSectionLiveTab;
