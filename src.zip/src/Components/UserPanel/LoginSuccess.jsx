import React from 'react'
import Login from './Login';

const LoginSuccess = () => {
  return (<>
   <Login/>
   <p>Successfully Registered with Hachion</p>
   </>)
}

export default LoginSuccess