import { createContext } from 'react';

export const BatchContext = createContext(null);