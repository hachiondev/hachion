
import React, { useState, useEffect } from "react";
import styles from "./DemoClassSection.module.css";
import { cn } from "../../utils";
// import RequestCustomBatch from "./RequestCustomBatch";
import RequestBatch from "../UserPanel/RequestBatch";

import EnrollNotification from "./EnrollNotification";
import { useParams } from "react-router-dom";
import { useCourseDiscountRule } from "../../Api/hooks/CourseApi/useCourseDiscountRule";
import { useDiscountCountdown } from "../../Api/hooks/CourseApi/useDiscountCountdown";
import { useUserProfile } from "../../Api/hooks/CourseApi/useUserProfile";
import { useDemoScheduleLogic } from "../../Api/hooks/DemoClassSectionLogics/useDemoScheduleLogic";
import { useDemoBatchRequestLogic } from "../../Api/hooks/DemoClassSectionLogics/useDemoBatchRequestLogic";
import DemoClassSectionLiveTab from "./DemoClassSectionLiveTab";
import DemoClassSectionCrashTab from "./DemoClassSectionCrashTab";
import DemoClassSectionMentoringTab from "./DemoClassSectionMentoringTab";
import DemoClassSectionSelfTab from "./DemoClassSectionSelfTab";
import { useCourseByName } from "../../Api/hooks/CourseApi/useCourseByName";
import { useDemoLivePayment } from "../../Api/hooks/CourseApi/useDemoLivePayment";
import axios from "axios";
const tabs = [
  { key: "live", label: "Live Training" },
  { key: "crash", label: "Crash Course (Fast Track)" },
  { key: "mentoring", label: "Mentoring Mode" },
  { key: "self", label: "Self-Paced Learning" },
];


export default function DemoClassSection() {
  const [activeTab, setActiveTab] = useState("live");
  const browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const [tz, setTz] = useState(browserTz);

  const [showRequestBatch, setShowRequestBatch] = useState(false);
  const [resetLiveSubmitting, setResetLiveSubmitting] = useState(0);
  const [enrollNow, setEnrollNow] = useState(false);

const [mentoringPreferredTime, setMentoringPreferredTime] = useState("");
const [mentoringNotification, setMentoringNotification] = useState("Email Only");
const [mentoringTimeDropdownOpen, setMentoringTimeDropdownOpen] = useState(false);
const [mentoringNotificationDropdownOpen, setMentoringNotificationDropdownOpen] = useState(false);

const [selfPreferredTime, setSelfPreferredTime] = useState("");
const [selfNotification, setSelfNotification] = useState("Email Only");
const [selfTimeDropdownOpen, setSelfTimeDropdownOpen] = useState(false);
const [selfNotificationDropdownOpen, setSelfNotificationDropdownOpen] = useState(false);

  const [showMessage, setShowMessage] = useState(false);

  const [enrollSuccessMessage, setEnrollSuccessMessage] = useState("");
const [enrollErrorMessage, setEnrollErrorMessage] = useState("");
  const [showRegisterPrompt, setShowRegisterPrompt] = useState(false);
const [enrollingSessionId, setEnrollingSessionId] = useState(null);
const [tabMessage, setTabMessage] = useState({
  live: false,
  crash: false,
  mentoring: false,
  self: false
});
useEffect(() => {
  if (!enrollSuccessMessage && !enrollErrorMessage) return;

  const timer = setTimeout(() => {
    setEnrollSuccessMessage("");
    setEnrollErrorMessage("");
  }, 6000);

  return () => clearTimeout(timer);
}, [enrollSuccessMessage, enrollErrorMessage]);

  const {
    data: userProfile,
    isLoading: isProfileLoading,
    
  } = useUserProfile();
  
const { courseName } = useParams();


const rawSlug = courseName ? decodeURIComponent(courseName) : "";

const normalizeCourseSlug = (slug) =>
  slug
    .replace(/[-_]+/g, " ")   // programming-with-c++ → programming with c++
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

const courseNameForApi = rawSlug ? normalizeCourseSlug(rawSlug) : "";


const courseSlug = rawSlug ? rawSlug.toLowerCase() : "";
const displayCourseName = courseNameForApi
  ? courseNameForApi.replace(/\w\S*/g, (txt) =>
      txt.charAt(0).toUpperCase() + txt.slice(1)
    )
  : "this course";

const {
  data: courseData,
  isLoading: isCourseLoading,
  error: courseError,
} = useCourseByName(courseNameForApi);


const {
  handleLiveEnrollPayment,

} = useDemoLivePayment({
  courseData,
  userProfile,
  courseNameForApi,
   setEnrollSuccessMessage,
  setEnrollErrorMessage
});
const handleLiveEnrollClick = async (session) => {
  if (!userProfile || !userProfile.studentId) {
    setShowRegisterPrompt(true);
    return;
  }
  setShowRegisterPrompt(false);
  setEnrollingSessionId(session.id);

  await handleLiveEnrollPayment(session);

  setEnrollingSessionId(null);
};


  const {
    liveGroups,
    crashGroups,
    scheduleTimeZoneAbbr,
    scheduleLoading,
    scheduleError,
  } = useDemoScheduleLogic({
    courseSlug,
    timezone: tz,
  });

  const [selectedGroupKey, setSelectedGroupKey] = useState(null);
  const selectedGroup =
    liveGroups.find((g) => g.key === selectedGroupKey) || null;

  const [selectedCrashDay, setSelectedCrashDay] = useState(null);
  const selectedCrashGroup =
    crashGroups.find((g) => g.day === selectedCrashDay) || null;

  const { data: discountRule } = useCourseDiscountRule(courseNameForApi);
  const hasSpecialDiscount = !!discountRule;
  const discountPct = discountRule?.discountPercentage ?? 0;

  const { timeLeft, isOfferActive } = useDiscountCountdown(discountRule);
  const showOfferStrip = hasSpecialDiscount && isOfferActive;


  const {
    handleRequestBatch,
    requestBatchError,
    isRequestBatchSuccess,
    isRequestBatchLoading,
  } = useDemoBatchRequestLogic({
    activeTab,
    scheduleTimeZoneAbbr,
    displayCourseName,
    browserTz,
    userProfile,
    isProfileLoading,
  });

  const handleRequestBatchWithLoginCheck = () => {
  // wait until profile loads
  if (isProfileLoading) return;
  if (!userProfile || !userProfile.studentId) {
    setShowRegisterPrompt(true);
    return;
  }
   setShowRequestBatch(true);
};

  const handleClick = () => {
    const selectedDays = Array.from(
      document.querySelectorAll(".dayCheckbox:checked")
    ).map((cb) => cb.nextSibling?.nextSibling?.textContent?.trim());

   const allowMentoringSelf = activeTab === "mentoring" || activeTab === "self";

const preferredTimeForTab =
  activeTab === "mentoring"
    ? mentoringPreferredTime
    : activeTab === "self"
    ? selfPreferredTime
    : null;


const notificationForTab =
  activeTab === "mentoring"
    ? mentoringNotification
    : activeTab === "self"
    ? selfNotification
    : null;

handleRequestBatch({
  preferredTime: allowMentoringSelf ? preferredTimeForTab : null,
  notification: allowMentoringSelf ? notificationForTab : null,
  selectedDays: allowMentoringSelf ? selectedDays : [],
});

  };

  const handleEnroll = () => {
    setEnrollNow(false);
  };

useEffect(() => {
  
  if (isRequestBatchSuccess) {
    document.querySelectorAll(".dayCheckbox").forEach(cb => (cb.checked = false));

    if (activeTab === "mentoring") {
      setMentoringPreferredTime("");
      setMentoringNotification("");
      setMentoringTimeDropdownOpen(false);
      setMentoringNotificationDropdownOpen(false);
    }

    if (activeTab === "self") {
      setSelfPreferredTime("");
      setSelfNotification("");
      setSelfTimeDropdownOpen(false);
      setSelfNotificationDropdownOpen(false);
    }
  }

  
  if (isRequestBatchSuccess || requestBatchError) {
    setTabMessage(prev => ({
      ...prev,
      [activeTab]: true
    }));

    const timer = setTimeout(() => {
      setTabMessage(prev => ({
        ...prev,
        [activeTab]: false
      }));
    }, 6000);

    return () => clearTimeout(timer);
  }
}, [
  isRequestBatchSuccess,
  requestBatchError
  
]);

  const timeOptions = [
    { value: "09:00 AM - 10:00 AM", label: "09:00 AM - 10:00 AM" },
    { value: "10:00 AM - 11:00 AM", label: "10:00 AM - 11:00 AM" },
    { value: "11:00 AM - 12:00 PM", label: "11:00 AM - 12:00 PM" },
    { value: "12:00 PM - 01:00 PM", label: "12:00 PM - 01:00 PM" },
    { value: "01:00 PM - 02:00 PM", label: "01:00 PM - 02:00 PM" },
    { value: "02:00 PM - 03:00 PM", label: "02:00 PM - 03:00 PM" },
    { value: "03:00 PM - 04:00 PM", label: "03:00 PM - 04:00 PM" },
    { value: "04:00 PM - 05:00 PM", label: "04:00 PM - 05:00 PM" },
    { value: "05:00 PM - 06:00 PM", label: "05:00 PM - 06:00 PM" },
  ];

  const notificationOptions = [
    { value: "WhatsApp / Email", label: "WhatsApp / Email" },
    { value: "Email Only", label: "Email Only" },
    { value: "WhatsApp Only", label: "WhatsApp Only" },
  ];

  return (
    <section className={styles.dcwrap}>
      <div className="container">
        {/* Offer strip */}
        {showOfferStrip && (
          <div className={styles.offerBanner}>
            <div className={styles.offerLeft}>
              <div className={styles.offerIcon} aria-hidden="true">
                <img src="Offer.png" alt="Offer" />
              </div>
              <div className={styles.offerText}>
                <div className={styles.offerTitle}>Happy Hours Offer!</div>
                <div className={styles.offerSubtitle}>
                  {discountPct > 0 ? (
                    <>
                      Get {discountPct}% Discount on{" "}
                      <strong>{displayCourseName}</strong>
                    </>
                  ) : (
                    <>
                      Special Discount on{" "}
                      <strong>{displayCourseName}</strong>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className={styles.offerCountdown}>
              <div className={styles.countPill}>
                Ends in{" "}
                {timeLeft.days > 0 && (
                  <>
                    <strong>
                      {String(timeLeft.days).padStart(2, "0")}
                    </strong>{" "}
                    days{" "}
                  </>
                )}
                <strong>
                  {String(timeLeft.hours).padStart(2, "0")}
                </strong>{" "}
                hr{" "}
                <strong>
                  {String(timeLeft.minutes).padStart(2, "0")}
                </strong>{" "}
                mins{" "}
                <strong>
                  {String(timeLeft.seconds).padStart(2, "0")}
                </strong>{" "}
                sec
              </div>
            </div>
          </div>
        )}

        {/* Heading */}
        <div className={styles.dchead}>
          <div className={styles.dcheadText}>
            <h2>Try Before You Enroll</h2>
            <p>
              Experience our world-class teaching methodology firsthand. Join
              an upcoming demo session or request a custom batch at your
              preferred time.
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className={styles.dctabs}>
          {tabs.map((t) => (
            <button
              key={t.key}
              className={cn(
                styles.dctab,
                activeTab === t.key && styles.dctabisactive
              )}
              onClick={() => setActiveTab(t.key)}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Tab contents moved to separate components */}
        {activeTab === "live" && (
          <DemoClassSectionLiveTab
            scheduleLoading={scheduleLoading}
            scheduleError={scheduleError}
            liveGroups={liveGroups}
            selectedGroupKey={selectedGroupKey}
            setSelectedGroupKey={setSelectedGroupKey}
            selectedGroup={selectedGroup}
            isRequestBatchLoading={isRequestBatchLoading}
            isProfileLoading={isProfileLoading}
            
            showMessage={tabMessage[activeTab]}

            isRequestBatchSuccess={isRequestBatchSuccess}
            requestBatchError={requestBatchError}
            // onRequestClick={handleClick}
            onRequestClick={handleRequestBatchWithLoginCheck}

            liveTraining={courseData?.liveTraining}       
    isCourseLoading={isCourseLoading}              
    courseError={courseError}  
      onEnrollClick={handleLiveEnrollClick} 
      enrollSuccessMessage={enrollSuccessMessage}
  enrollErrorMessage={enrollErrorMessage}
         userProfile={userProfile}
    courseName={courseData?.courseName || courseNameForApi}
     showRegisterPrompt={showRegisterPrompt}
    onCloseRegisterPrompt={() => setShowRegisterPrompt(false)}
enrollingSessionId={enrollingSessionId}
resetLiveSubmitting={resetLiveSubmitting}

     
          />
        )}

        {activeTab === "crash" && (
          <DemoClassSectionCrashTab
            scheduleLoading={scheduleLoading}
            scheduleError={scheduleError}
            crashGroups={crashGroups}
            selectedCrashDay={selectedCrashDay}
            setSelectedCrashDay={setSelectedCrashDay}
            selectedCrashGroup={selectedCrashGroup}
            isRequestBatchLoading={isRequestBatchLoading}
            isProfileLoading={isProfileLoading}
            showMessage={tabMessage[activeTab]}
            isRequestBatchSuccess={isRequestBatchSuccess}
            requestBatchError={requestBatchError}
            onRequestClick={handleClick}
             crashCourse={courseData?.crashCourse || ""}
    isCourseLoading={isCourseLoading}                
    courseError={courseError}     
          />
        )}
{activeTab === "mentoring" && (
  <DemoClassSectionMentoringTab
    timeOptions={timeOptions}
    notificationOptions={notificationOptions}
    preferredTime={mentoringPreferredTime}
    setPreferredTime={setMentoringPreferredTime}
    notification={mentoringNotification}
    setNotification={setMentoringNotification}
    timeDropdownOpen={mentoringTimeDropdownOpen}
    setTimeDropdownOpen={setMentoringTimeDropdownOpen}
    notificationDropdownOpen={mentoringNotificationDropdownOpen}
    setNotificationDropdownOpen={setMentoringNotificationDropdownOpen}
    isRequestBatchLoading={isRequestBatchLoading}
    isProfileLoading={isProfileLoading}
    showMessage={tabMessage[activeTab]}
    isRequestBatchSuccess={isRequestBatchSuccess}
    requestBatchError={requestBatchError}
    onRequestClick={handleClick}
     mentoringMode={courseData?.mentoringMode || ""}  
    isCourseLoading={isCourseLoading}                
    courseError={courseError}     
          
  />
)}
{activeTab === "self" && (
  <DemoClassSectionSelfTab
    timeOptions={timeOptions}
    notificationOptions={notificationOptions}
    preferredTime={selfPreferredTime}
    setPreferredTime={setSelfPreferredTime}
    notification={selfNotification}
    setNotification={setSelfNotification}
    timeDropdownOpen={selfTimeDropdownOpen}
    setTimeDropdownOpen={setSelfTimeDropdownOpen}
    notificationDropdownOpen={selfNotificationDropdownOpen}
    setNotificationDropdownOpen={setSelfNotificationDropdownOpen}
    isRequestBatchLoading={isRequestBatchLoading}
    isProfileLoading={isProfileLoading}
    showMessage={tabMessage[activeTab]}
    isRequestBatchSuccess={isRequestBatchSuccess}
    requestBatchError={requestBatchError}
    onRequestClick={handleClick}
      selfPacedLearning={courseData?.selfPacedLearning || ""}  
    isCourseLoading={isCourseLoading}  
  />
)}

        {/* {showRequestBatch && (
          <RequestCustomBatch
            onClose={() => setShowRequestBatch(false)}
            onSubmit={(formData) => {
              console.log("Custom batch request submitted:", formData);
              setShowRequestBatch(false);
            }}
          />
        )} */}
       {showRequestBatch && (
  <RequestBatch
    closeModal={() => {
      setShowRequestBatch(false);
      setResetLiveSubmitting(Date.now()); // ✅ RESET BUTTON STATE
    }}
  />
)}


      </div>

      {enrollNow && (
        <EnrollNotification
          open={enrollNow}
          onClose={() => setEnrollNow(false)}
          onEnroll={handleEnroll}
        />
      )}
    </section>
  );
}
